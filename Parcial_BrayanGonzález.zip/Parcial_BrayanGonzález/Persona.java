package Parcial_BrayanGonzález;

public class Persona {
    private String nombre = "";
    private int edad;
    private double altura;
    private double peso;
    private String sexo;

    public Persona(String nombre, int edad, double altura, double peso, String sexo){
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
        this.peso = peso;
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String isSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public static void Caminar(ObjetosPersona persona){
        System.out.println("El "+ persona.getRango() + " con nombre: "  + persona.getNombre() + " se encuentra caminando.");
    }
    public static void Tiempo(ObjetosPersona persona){
        System.out.println("Acabas de viajar en el  tiempo y paso un año, ahora " + persona.getNombre() + " tiene un año mas edad actual: " + persona.getEdad());
    }
    public static void Consultar(ObjetosPersona persona){
        System.out.println("Nombre: " + persona.getNombre() + " Edad: " + persona.getEdad() + " Altura: " + persona.getAltura() + " Peso: " + persona.getPeso() + " Sexo: " + persona.isSexo() + " Rango: " + persona.getRango());
    }
}
