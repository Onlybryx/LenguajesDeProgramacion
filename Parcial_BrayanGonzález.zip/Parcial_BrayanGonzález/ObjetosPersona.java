package Parcial_BrayanGonzález;

public class ObjetosPersona extends Persona {

    public String getRango() {
        return Rango;
    }
    public void setRango(String rango) {
        Rango = rango;
    }
    private String Rango = "";

    public ObjetosPersona(String nombre, int edad, double altura, double peso, String sexo, String Rango) {
        super(nombre, edad, altura, peso, sexo);
        this.Rango = Rango;
    }

    
}
