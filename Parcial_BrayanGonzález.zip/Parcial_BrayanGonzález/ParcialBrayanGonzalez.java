package Parcial_BrayanGonzález;
public class ParcialBrayanGonzalez{
    public static void main (String[] args){
        System.out.println("____________");
        ObjetosPersona Maestro = new ObjetosPersona("Diego", 26, 1.75, 60, "Masculino", "Profesor Lenguajes");
        ObjetosPersona Estudiante = new ObjetosPersona("Brayan", 17, 1.91, 73.3, "Masculino", "Estudiante Sistemas");
        ObjetosPersona Directivo = new ObjetosPersona("Edison", 32, 1.56, 64, "Masculino", "Coordinador de programación");
        
        Maestro.Consultar(Maestro);
        Estudiante.Consultar(Estudiante);
        Directivo.Consultar(Directivo);
        System.out.println("____________");
        Maestro.Caminar(Maestro);
        Estudiante.Caminar(Estudiante);
        Directivo.Caminar(Directivo);
        System.out.println("____________");
        Maestro.Tiempo(Maestro);
        Estudiante.Tiempo(Estudiante);
        Directivo.Tiempo(Directivo);
        System.out.println("____________");
    }
}